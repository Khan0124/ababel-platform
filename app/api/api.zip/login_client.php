<?php
header('Content-Type: application/json');
require_once '../config.php'; // الاتصال بقاعدة البيانات

$data = json_decode(file_get_contents("php://input"), true);
$code = $data['code'] ?? '';
$password = $data['password'] ?? '';

if (!$code || !$password) {
    echo json_encode(['status' => 'error', 'message' => 'بيانات ناقصة']);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM clients WHERE code = ?");
$stmt->bind_param("s", $code);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'العميل غير موجود']);
    exit;
}

$client = $result->fetch_assoc();
if (!password_verify($password, $client['password'])) {
    echo json_encode(['status' => 'error', 'message' => 'كلمة المرور غير صحيحة']);
    exit;
}

// الآن نرجع بيانات العميل كاملة مع الأرصدة
echo json_encode([
    'status' => 'success',
    'client' => [
        'id' => $client['id'],
        'name' => $client['name'],
        'code' => $client['code'],
        'balance' => $client['balance'],
        'insurance_balance' => $client['insurance_balance'],
        'phone' => $client['phone'],
        'start_date' => $client['start_date'],
        // لو تحب تضيف بيانات أخرى هنا
    ]
]);
?>
