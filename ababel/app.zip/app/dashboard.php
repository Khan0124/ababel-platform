<?php
include 'auth.php';
include 'config.php';
include 'backup_notice_for_dashboard.php';

$username = $_SESSION['username'] ?? 'الموظف';
$lang = $_GET['lang'] ?? ($_SESSION['lang'] ?? 'ar');
$_SESSION['lang'] = $lang;

// البيانات الإحصائية
$client_count = $conn->query("SELECT COUNT(*) as total FROM clients")->fetch_assoc()['total'] ?? 0;
$container_count = $conn->query("SELECT COUNT(*) as total FROM containers")->fetch_assoc()['total'] ?? 0;
$balance = $conn->query("SELECT
  (SELECT SUM(amount) FROM cashbox WHERE type = 'قبض' AND (source IS NULL OR source != 'رصيد التأمين')) -
  (SELECT SUM(amount) FROM cashbox WHERE type = 'صرف' AND (source IS NULL OR source != 'استرداد التأمين')) AS total
")->fetch_assoc()['total'] ?? 0;

// الرصيد التأميني
$insurance_balance = $conn->query("SELECT
  (IFNULL((SELECT SUM(amount) FROM cashbox WHERE type = 'قبض' AND source = 'رصيد التأمين'), 0) -
  IFNULL((SELECT SUM(amount) FROM cashbox WHERE type = 'صرف' AND source = 'استرداد التأمين'), 0) -
  IFNULL((SELECT SUM(amount) FROM cashbox WHERE type = 'قبض' AND source = 'تحويل من التأمين'), 0)) AS total
")->fetch_assoc()['total'] ?? 0;


// الحاويات اقتربت من الأرضيات
$near_ground = $conn->query("
SELECT c.id, c.container_number, cs.created_at
FROM containers c
JOIN (
  SELECT * FROM container_status WHERE id IN (
    SELECT MAX(id) FROM container_status GROUP BY container_id
  )
) cs ON c.id = cs.container_id
WHERE cs.status = 'في الميناء' AND DATEDIFF(NOW(), cs.created_at) >= 18
");

// الحاويات تجاوزت 30 يومًا ولم يتم تحديث حالتها إطلاقًا
$overdue_containers = $conn->query("
SELECT c.id, c.container_number, c.entry_date
FROM containers c
LEFT JOIN container_status cs ON c.id = cs.container_id
WHERE cs.id IS NULL AND DATEDIFF(NOW(), c.entry_date) >= 30
");

// آخر العمليات
$recent_ops = $conn->query("
SELECT cb.*, u.full_name FROM cashbox cb
LEFT JOIN users u ON cb.user_id = u.id
ORDER BY cb.created_at DESC
LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $lang == 'ar' ? 'rtl' : 'ltr' ?>">
<head>
  <meta charset="UTF-8">
  <title>لوحة تحكم أبابيل</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body { font-family: 'Cairo', sans-serif; background: #f9f9f9; }
    .navbar-custom {
      background-color: #711739;
      padding: 10px 20px;
    }
    .navbar-custom .navbar-brand,
    .navbar-custom .nav-link,
    .navbar-custom .dropdown-toggle {
      color: white !important;
      font-weight: bold;
    }
    .navbar-custom .nav-link:hover {
      background-color: #8a1c47;
      border-radius: 6px;
    }
    .logo-img { height: 50px; margin-left: 10px; }
    .dropdown-menu { text-align: <?= $lang === 'ar' ? 'right' : 'left' ?>; }
    .welcome { margin-top: 50px; text-align: center; color: #711739; }
    .card-box { background: white; padding: 15px; border-radius: 10px; box-shadow: 0 0 5px #ccc; }
    .dashboard-section { padding: 30px 20px; }
    .section-title { color: #711739; margin-bottom: 15px; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
      <img src="logo.png" alt="شعار" class="logo-img">
      <span>أبابيل</span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarLinks">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarLinks">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="dashboard.php">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link" href="clients_list.php">العملاء</a></li>
        <li class="nav-item"><a class="nav-link" href="containers.php">الحاويات</a></li>
        <li class="nav-item"><a class="nav-link" href="cashbox.php">الخزنة</a></li>
        <li class="nav-item"><a class="nav-link" href="reports.php">التقارير</a></li>
      </ul>
      <div class="dropdown">
        <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown">القائمة</button>
        <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="commercial_operations.php"> 📚 العمليات التجارية</a></
          <li><a class="dropdown-item" href="gov_actions.php"> 🏛️ الإجراءات الحكومية</a></li>
          <li><a class="dropdown-item" href="registries.php"> 🗃️ السجلات</a></li>
          <li><a class="dropdown-item" href="daily_expense_list.php">📋 يوميات الصرف</a></li>
          <li><a class="dropdown-item" href="documents.php">📁 المستندات</a></li
          <li><a class="dropdown-item" href="settings.php">⚙️ الإعدادات</a></li>
          <li><a class="dropdown-item" href="users.php">👥 الموظفين</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="?lang=ar">🇸🇦 اللغة العربية</a></li>
          <li><a class="dropdown-item" href="?lang=en">🇬🇧 English</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="logout.php">🚪 تسجيل الخروج</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<div class="container dashboard-section">
  <div class="welcome">
    <h2>مرحبًا بك يا <?= htmlspecialchars($username) ?> في لوحة تحكم شركة أبابيل</h2>
    <p>اختر من القائمة أعلاه للتنقل بين الأقسام.</p>
  </div>

  <div class="row mt-4 text-center">
    <div class="col-md-3 mb-3"><div class="card-box">👤 <strong>عدد العملاء:</strong> <?= $client_count ?></div></div>
    <div class="col-md-3 mb-3"><div class="card-box">📦 <strong>عدد الحاويات:</strong> <?= $container_count ?></div></div>
    <div class="col-md-3 mb-3"><div class="card-box">💰 <strong>الرصيد الحالي:</strong> <?= number_format($balance) ?> جنيه</div></div>
<div class="col-md-3 mb-3">
  <div class="card-box">🛡️ <strong>رصيد التأمين:</strong> <?= number_format($insurance_balance) ?> جنيه</div>
</div>



  <div class="row mt-4">
    <div class="col-md-6 mb-4">
      <div class="card-box">
        <h5 class="section-title">🚨 الحاويات التي اقتربت من الأرضيات</h5>
        <ul class="list-group">
          <?php if ($near_ground->num_rows > 0): while($c = $near_ground->fetch_assoc()): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <?= $c['container_number'] ?>
              <span class="badge bg-danger">قضت <?= (new DateTime())->diff(new DateTime($c['created_at']))->days ?> يوم</span>
            </li>
          <?php endwhile; else: ?>
            <li class="list-group-item">لا توجد حاويات قريبة من فترة الأرضيات.</li>
          <?php endif; ?>
        </ul>
      </div>
    </div>

    <div class="col-md-6 mb-4">
      <div class="card-box">
        <h5 class="section-title">⏳ حاويات تجاوزت 30 يومًا من تاريخ الشحن ولم يتم تحديث حالتها</h5>
        <ul class="list-group">
          <?php if ($overdue_containers->num_rows > 0): while($c = $overdue_containers->fetch_assoc()): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <?= $c['container_number'] ?> (منذ <?= (new DateTime())->diff(new DateTime($c['entry_date']))->days ?> يوم)
              <a href="view_container.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary">عرض</a>
            </li>
          <?php endwhile; else: ?>
            <li class="list-group-item">لا توجد حاويات تجاوزت 30 يومًا بدون حالة.</li>
          <?php endif; ?>
        </ul>
      </div>
    </div>

    <div class="col-md-12 mb-4">
      <div class="card-box">
        <h5 class="section-title">🧾 آخر العمليات المالية</h5>
        <ul class="list-group">
          <?php while($op = $recent_ops->fetch_assoc()): ?>
            <li class="list-group-item">
              <?= $op['description'] ?> | <?= $op['type'] ?> | <?= number_format($op['amount']) ?> | <?= date('Y-m-d', strtotime($op['created_at'])) ?>
              <span class="text-muted float-end"> <?= $op['full_name'] ?? '' ?> </span>
            </li>
          <?php endwhile; ?>
        </ul>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- زر مزامنة عائم + حالة الاتصال --><!-- زر مزامنة -->
<button id="syncBtn" title="مزامنة" style="
  position: fixed;
  bottom: 20px;
  left: 20px;
  z-index: 9999;
  background-color: #0d6efd;
  color: white;
  border: none;
  padding: 12px 20px;
  border-radius: 30px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.2);
">🔁 مزامنة</button>

<!-- إشعار -->
<div id="syncStatus" style="
  position: fixed;
  bottom: 80px;
  left: 20px;
  z-index: 9999;
  display: none;
  background: #fff3cd;
  color: #856404;
  border: 1px solid #ffeeba;
  padding: 10px 15px;
  border-radius: 8px;
  font-size: 14px;
  max-width: 300px;
"></div>

<script>
const syncBtn = document.getElementById('syncBtn');
const syncStatus = document.getElementById('syncStatus');

// تحديد ملف المزامنة حسب البيئة (محلي أو سيرفر)
const isLocal = location.hostname === 'localhost';
const syncScript = isLocal ? 'sync_send.php' : 'sync_receive_all.php';

function syncData() {
  syncBtn.disabled = true;
  syncStatus.innerHTML = '⏳ جاري المزامنة...';
  syncStatus.style.display = 'block';

  fetch(syncScript)
    .then(res => res.text())
    .then(data => {
      syncStatus.innerHTML = '✅ تمت المزامنة بنجاح!';
      console.log('✅ رد:', data);
      setTimeout(() => syncStatus.style.display = 'none', 5000);
      syncBtn.disabled = false;
    })
    .catch(err => {
      syncStatus.innerHTML = '❌ فشل الاتصال أو السيرفر غير متاح.';
      console.error('❌ خطأ:', err);
      syncBtn.disabled = false;
    });
}

syncBtn.addEventListener('click', syncData);
</script>

<script>
// التحويل عند فقد الإنترنت
window.addEventListener('offline', () => {
  alert('❌ تم فقد الاتصال بالإنترنت. يتم التحويل إلى النظام المحلي...');
  window.location.href = 'http://localhost/ababel/app/dashboard.php';
});

// التحويل عند عودة الإنترنت (إذا كنت في النسخة المحلية فقط)
window.addEventListener('online', () => {
  if (location.hostname === 'localhost') {
    alert('✅ تم استعادة الاتصال. العودة إلى النظام الأونلاين...');
    window.location.href = 'https://ababel.net/app/dashboard.php';
  } else {
    syncStatus.innerHTML = '✅ تم استعادة الاتصال. تتم الآن المزامنة...';
    syncStatus.style.display = 'block';
    syncData();
  }
});
</script>

</body>
</html>
