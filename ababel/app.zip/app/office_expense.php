
<?php
include 'config.php';
include 'auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['description'])) {
  $descriptions = $_POST['description'];
  $methods = $_POST['method'];
  $amounts = $_POST['amount'];
  $notes = $_POST['notes'];
  $user_id = $_SESSION['user_id'] ?? null;

  for ($i = 0; $i < count($descriptions); $i++) {
    $desc = $conn->real_escape_string($descriptions[$i]);
    $method = $conn->real_escape_string($methods[$i]);
    $amount = floatval($amounts[$i]);
    $note = $conn->real_escape_string($notes[$i]);

    $conn->query("INSERT INTO cashbox (type, source, description, method, amount, notes, client_id, user_id)
                  VALUES ('صرف', 'مصروفات مكتب', '$desc', '$method', $amount, '$note', NULL, $user_id)");
  }

  header("Location: office_expense.php");
  exit;
}

$expenses = $conn->query("SELECT * FROM cashbox WHERE type='صرف' AND source='مصروفات مكتب' ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>مصروفات المكتب</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Cairo', sans-serif;
      background-color: #f7f7f7;
      padding: 30px;
    }
    h2, h3 {
      text-align: center;
      color: #711739;
      margin-bottom: 20px;
    }
    .btn-primary, .btn-success, .btn-dark {
      background-color: #711739;
      border-color: #711739;
    }
    .btn-primary:hover, .btn-success:hover, .btn-dark:hover {
      background-color: #8c1d46;
    }
    .card {
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      background: #fff;
      margin-bottom: 30px;
    }
    table {
      background-color: white;
      border-radius: 8px;
      overflow: hidden;
    }
    th {
      background-color: #711739;
      color: white;
    }
    .form-control, .form-select {
      border-radius: 6px;
    }
    .action-links a {
      margin: 0 5px;
      font-weight: bold;
      color: #711739;
      text-decoration: none;
    }
    .action-links a:hover {
      text-decoration: underline;
    }
    .filters label {
      font-weight: bold;
      margin-left: 10px;
    }
  </style>
</head>
<body>

<a href="cashbox.php" class="btn btn-secondary mb-4">⬅️ الرجوع إلى الخزنة</a>

<div class="card p-4">
  <h2>🧾 تسجيل مصروفات مكتب</h2>
  <form method="POST">
    <table class="table text-center align-middle" id="expenseTable">
      <thead>
        <tr>
          <th>نوع المصروف</th>
          <th>طريقة الدفع</th>
          <th>المبلغ</th>
          <th>ملاحظات</th>
          <th>حذف</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <select name="description[]" class="form-select">
              <option value="حركة">حركة</option>
              <option value="أدوات مكتبية">أدوات مكتبية</option>
              <option value="كهرباء">كهرباء</option>
              <option value="مياه">مياه</option>
              <option value="صيانة">صيانة</option>
              <option value="اتصالات">اتصالات</option>
              <option value="ضيافة">ضيافة</option>
              <option value="مرتبات">مرتبات</option>
              <option value="حوافز">حوافز</option>
              <option value="إكراميات">إكراميات</option>
              <option value="إيجارات">إيجارات</option>
              <option value="أصول">أصول</option>
              <option value="أخرى">أخرى</option>
            </select>
          </td>
          <td>
            <select name="method[]" class="form-select">
              <option value="كاش">كاش</option>
              <option value="بنكك">بنكك</option>
              <option value="أوكاش">أوكاش</option>
              <option value="فوري">فوري</option>
              <option value="شيك">شيك</option>
            </select>
          </td>
          <td><input type="number" name="amount[]" step="0.01" class="form-control" required></td>
          <td><textarea name="notes[]" rows="1" class="form-control"></textarea></td>
          <td><button type="button" class="btn btn-sm btn-danger" onclick="removeRow(this)">🗑️</button></td>
        </tr>
      </tbody>
    </table>
    <div class="d-flex justify-content-between">
      <button type="button" class="btn btn-dark" onclick="addRow()">➕ إضافة سطر جديد</button>
      <button type="submit" class="btn btn-success">💾 حفظ المصروفات</button>
    </div>
  </form>
</div>

<div class="card p-4">
  <h3>📋 المنصرفات الإدارية</h3>
  <div class="filters d-flex flex-wrap align-items-center mb-3">
    <label>نوع المصروف:</label>
    <select id="filterType" class="form-select w-auto" onchange="filterTable()">
      <option value="">الكل</option>
      <option value="حركة">حركة</option>
      <option value="أدوات مكتبية">أدوات مكتبية</option>
      <option value="كهرباء">كهرباء</option>
      <option value="مياه">مياه</option>
      <option value="صيانة">صيانة</option>
      <option value="اتصالات">اتصالات</option>
      <option value="ضيافة">ضيافة</option>
      <option value="مرتبات">مرتبات</option>
      <option value="حوافز">حوافز</option>
      <option value="إكراميات">إكراميات</option>
      <option value="إيجارات">إيجارات</option>
      <option value="أصول">أصول</option>
      <option value="أخرى">أخرى</option>
    </select>
    <label class="ms-3">من:</label>
    <input type="date" id="fromDate" class="form-control w-auto" onchange="filterTable()">
    <label class="ms-3">إلى:</label>
    <input type="date" id="toDate" class="form-control w-auto" onchange="filterTable()">
  </div>

  <table class="table table-bordered text-center" id="adminTable">
    <thead>
      <tr>
        <th>التاريخ</th>
        <th>المصروف</th>
        <th>الطريقة</th>
        <th>المبلغ</th>
        <th>ملاحظات</th>
        <th>الإجراءات</th>
      </tr>
    </thead>
    <tbody>
     <tbody>
<?php while($row = $expenses->fetch_assoc()): ?>
<tr>
  <td><?= $row['created_at'] ?></td>
  <td><?= htmlspecialchars($row['description']) ?></td>
  <td><?= htmlspecialchars($row['method']) ?></td>
  <td><?= number_format($row['amount'], 2) ?></td>
  <td><?= htmlspecialchars($row['notes'] ?? '-') ?></td>
  <td class="action-links">
    <a href="expense_view.php?id=<?= $row['id'] ?>">عرض</a>
    <a href="edit_expense.php?id=<?= $row['id'] ?>">تعديل</a>
    <a href="delete_expense.php?id=<?= $row['id'] ?>" onclick="return confirm('هل أنت متأكد من الحذف؟')">حذف</a>
    <a href="print_expense.php?id=<?= $row['id'] ?>">طباعة</a>
  </td>
</tr>
<?php endwhile; ?>
</tbody> 
    </tbody>
  </table>
</div>

<script>
function addRow() {
  const table = document.getElementById("expenseTable").getElementsByTagName('tbody')[0];
  const newRow = table.rows[0].cloneNode(true);
  newRow.querySelectorAll("input, textarea").forEach(el => el.value = "");
  table.appendChild(newRow);
}
function removeRow(btn) {
  const row = btn.closest("tr");
  const table = row.closest("tbody");
  if (table.rows.length > 1) row.remove();
}
function filterTable() {
  const type = document.getElementById("filterType").value;
  const from = document.getElementById("fromDate").value;
  const to = document.getElementById("toDate").value;
  const rows = document.querySelectorAll("#adminTable tbody tr");
  rows.forEach(row => {
    const rowDate = row.children[0].textContent.substring(0, 10);
    const rowType = row.children[1].textContent.trim();
    const matchType = !type || rowType === type;
    const matchFrom = !from || rowDate >= from;
    const matchTo = !to || rowDate <= to;
    row.style.display = (matchType && matchFrom && matchTo) ? "" : "none";
  });
}
</script>

</body>
</html>