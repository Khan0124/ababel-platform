<?php
include 'auth.php';
include 'config.php';
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>إضافة حاوية</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet" />
  <style>
    body { font-family: 'Cairo', sans-serif; background: #f4f4f4; }
    .header { display: flex; align-items: center; justify-content: space-between; padding: 15px 30px; background: white; border-bottom: 2px solid #ddd; }
    .header img { height: 50px; }
    .header .company-name { text-align: center; flex-grow: 1; }
    .container { background: white; padding: 30px; margin-top: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.05); }
    @media (max-width: 768px) {
      .row > div { margin-bottom: 15px; }
    }
  </style>
</head>
<body>

<div class="header">
  <img src="logo.png" alt="Logo" />
  <div class="company-name">
    <h5 class="mb-0">شركة أبابيل للتنمية والاستثمار المحدودة</h5>
    <small>ABABEL FOR DEVELOPMENT AND INVESTMENT CO. LTD</small>
  </div>
</div>

<div class="container">
  <h4 class="text-center mb-4">➕ إضافة حاوية جديدة</h4>

  <?php if (isset($_GET['error'])): ?>
    <?php if ($_GET['error'] === 'duplicate_container'): ?>
      <div class="alert alert-danger text-center">⚠️ رقم الحاوية مستخدم مسبقًا.</div>
    <?php elseif ($_GET['error'] === 'duplicate_loading'): ?>
      <div class="alert alert-warning text-center">⚠️ رقم اللودنق مستخدم مسبقًا.</div>
    <?php endif; ?>
  <?php elseif (isset($_GET['added'])): ?>
    <div class="alert alert-success text-center">✅ تم حفظ الحاوية بنجاح!</div>
  <?php endif; ?>

  <form action="insert_container.php" method="POST">
    <div class="row g-3">
      <div class="col-md-4">
        <label class="form-label">تاريخ الشحن</label>
        <input type="date" name="entry_date" class="form-control" />
      </div>
      <div class="col-md-4">
        <label class="form-label">رقم العميل *</label>
        <input type="text" id="client_code" name="client_code" class="form-control" oninput="fetchClientName()" required />
      </div>
      <div class="col-md-4">
        <label class="form-label">اسم العميل</label>
        <input type="text" id="client_name" name="client_name" class="form-control" readonly />
      </div>

      <div class="col-md-4">
        <label class="form-label">رقم اللودنق</label>
        <input type="text" name="loading_number" class="form-control" />
      </div>
      <div class="col-md-4">
        <label class="form-label">عدد الكراتين</label>
        <input type="number" name="carton_count" class="form-control" min="0" />
      </div>
      <div class="col-md-4">
        <label class="form-label">رقم الحاوية *</label>
        <input type="text" name="container_number" class="form-control" required />
      </div>

      <div class="col-md-4">
        <label class="form-label">رقم البوليصة</label>
        <input type="text" name="bill_number" class="form-control" />
      </div>
      <div class="col-md-4">
        <label class="form-label">الصنف</label>
        <input type="text" name="category" class="form-control" />
      </div>
      <div class="col-md-4">
        <label class="form-label">الشركة الناقلة</label>
        <input type="text" name="carrier" class="form-control" />
      </div>

      <div class="col-md-4">
        <label class="form-label">السجل</label>
        <select name="registry" class="form-select">
          <option value="">اختر سجل</option>
          <?php
          $res = $conn->query("SELECT id, name FROM registers");
          while ($row = $res->fetch_assoc()) {
            echo "<option value='" . (int)$row['id'] . "'>" . htmlspecialchars($row['name']) . "</option>";
          }
          ?>
        </select>
      </div>

      <div class="col-md-4">
        <label class="form-label">الوزن</label>
        <input type="number" step="0.01" name="weight" class="form-control" />
      </div>
      <div class="col-md-4">
        <label class="form-label">تاريخ الوصول المتوقع</label>
        <input type="date" name="expected_arrival" class="form-control" />
      </div>

      <div class="col-md-6">
        <label class="form-label">اسم الباخرة</label>
        <input type="text" name="ship_name" class="form-control" />
      </div>
      <div class="col-md-6">
        <label class="form-label">المحطة الجمركية</label>
        <input type="text" name="custom_station" class="form-control" />
      </div>
      <div class="col-md-6">
        <label class="form-label">مكان التفريغ</label>
        <input type="text" name="unloading_place" class="form-control" />
      </div>

      <div class="col-12">
        <label class="form-label">ملاحظات</label>
        <textarea name="notes" class="form-control" rows="2"></textarea>
      </div>

      <div class="col-md-6">
        <label class="form-label">Release</label>
        <select name="release_status" class="form-select">
          <option value="No" selected>No</option>
          <option value="Yes">Yes</option>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Company Release</label>
        <select name="company_release" class="form-select">
          <option value="No" selected>No</option>
          <option value="Yes">Yes</option>
        </select>
      </div>
    </div>

    <div class="text-center mt-4">
      <button type="submit" class="btn btn-primary px-5">➕ حفظ</button>
    </div>
  </form>
</div>

<script>
function fetchClientName() {
  const code = document.getElementById('client_code').value.trim();
  if (!code) {
    document.getElementById('client_name').value = '';
    return;
  }
  fetch('fetch_client_name.php?code=' + encodeURIComponent(code))
    .then(res => res.text())
    .then(name => {
      document.getElementById('client_name').value = name || '';
    })
    .catch(() => {
      document.getElementById('client_name').value = '';
    });
}
</script>

</body>
</html>
