<?php
include 'config.php';
include 'auth.php';

$id = $_GET['id'] ?? 0;
if (!$id) {
  die("رقم الحاوية غير صالح.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $status = $_POST['status'];
  $driver_name = $_POST['driver_name'] ?? null;
  $driver_phone = $_POST['driver_phone'] ?? null;
  $truck_number = $_POST['truck_number'] ?? null;
  $destination = $_POST['destination'] ?? null;
  $custom_station = $_POST['custom_station'] ?? null;

  $stmt = $conn->prepare("INSERT INTO container_status 
    (container_id, status, driver_name, driver_phone, truck_number, destination, custom_station, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
  $stmt->bind_param("issssss", $id, $status, $driver_name, $driver_phone, $truck_number, $destination, $custom_station);
  $stmt->execute();

  header("Location: containers.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>تحديث حالة الحاوية</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body { padding: 30px; background: #f9f9f9; }
    .form-control, select { margin-bottom: 15px; }
    .hidden { display: none; }
  </style>
  <script>
    function toggleDriverFields() {
      const status = document.getElementById("status").value;
      const driverFields = document.getElementById("driverFields");
      driverFields.style.display = (status === "في الترحيل") ? "block" : "none";
    }
    function toggleDriverFields() {
  const status = document.getElementById("status").value;
  const driverFields = document.getElementById("driverFields");
  const required = (status === "في الترحيل");
  
  driverFields.style.display = required ? "block" : "none";
  
  document.querySelectorAll("#driverFields input").forEach(input => {
    input.required = required;
  });
}
  </script>
  
</head>
<body>
<div class="container">
  <h3 class="mb-4">🔄 تحديث حالة الحاوية</h3>
  <form method="POST">
    <label>الحالة:</label>
    <select id="status" name="status" class="form-control" onchange="toggleDriverFields()" required>
      <option value="">-- اختر الحالة --</option>
      <option value="لم تصل">لم تصل</option>
      <option value="في البحر">في البحر</option>
      <option value="لم تفرغ">لم تفرغ</option>
      <option value="فرغت">فرغت</option>
      <option value="في الترحيل">في الترحيل</option>
      <option value="في الميناء">في الميناء</option>
      <option value="تم التسليم">تم التسليم</option>
    </select>

    <div id="driverFields" class="hidden">
      <label>اسم السائق:</label>
      <input type="text" name="driver_name" class="form-control">
      <label>رقم الهاتف:</label>
      <input type="text" name="driver_phone" class="form-control">
      <label>رقم العربة:</label>
      <input type="text" name="truck_number" class="form-control">
    </div>

    <label>وجهة الحاوية:</label>
    <input type="text" name="destination" class="form-control">

    <label>المحطة الجمركية:</label>
    <input type="text" name="custom_station" class="form-control">

    <button class="btn btn-primary">💾 حفظ</button>
  </form>
</div>


</body>
</html>