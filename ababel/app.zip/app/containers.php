<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include 'auth.php';
include 'config.php';

// تعريف الحقول مع التسمية
$fields = [
  'container_number' => 'رقم الحاوية',
  'carrier' => 'الشركة الناقلة',
  'client_name' => 'اسم العميل',
  'code' => 'رقم العميل',
  'bill_number' => 'رقم البوليصة',
  'category' => 'الصنف',
  'registry' => 'السجل',
  'expected_arrival' => 'تاريخ الوصول المتوقع',
  'ship_name' => 'الباخرة',
  'custom_station' => 'المحطة الجمركية',
  'notes' => 'ملاحظات',
  'release_status' => 'تم الإفراج',
  'company_release' => 'تم الإفراج من الشركة',
];

// استلام الفلاتر والفرز والصفحة من URL مع تعيين القيم الافتراضية
$filters = [
  'field1' => $_GET['field1'] ?? '',
  'value1' => $_GET['value1'] ?? '',
  'field2' => $_GET['field2'] ?? '',
  'value2' => $_GET['value2'] ?? '',
  'field3' => $_GET['field3'] ?? '',
  'value3' => $_GET['value3'] ?? '',
  'from' => $_GET['from'] ?? '',
  'to' => $_GET['to'] ?? '',
];

// فرز الأعمدة
$order_by = $_GET['order_by'] ?? 'id';
$order_dir = $_GET['order_dir'] ?? 'DESC';

if (!array_key_exists($order_by, $fields) && $order_by !== 'entry_date' && $order_by !== 'id') {
  $order_by = 'id'; // افتراضي
}
$order_dir = strtoupper($order_dir);
if (!in_array($order_dir, ['ASC', 'DESC'])) {
  $order_dir = 'DESC';
}

// للصفحات Pagination
$items_per_page = 10;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page -1) * $items_per_page;

// دالة لجلب خيارات الفلترة لكل حقل
function getOptions($field, $conn) {
  $opts = [];
  if (!empty($field)) {
    $stmt = $conn->prepare("SELECT DISTINCT `$field` as val FROM containers ORDER BY `$field` ASC");
    if ($stmt) {
      $stmt->execute();
      $res = $stmt->get_result();
      while ($r = $res->fetch_assoc()) {
        $val = $r['val'] !== '' ? $r['val'] : 'غير محدد';
        $opts[] = $val;
      }
      $stmt->close();
    }
  }
  return $opts;
}

// بناء شروط WHERE مع معاملات Prepared Statements
$whereClauses = [];
$params = [];
$types = "";

for ($i=1; $i<=3; $i++) {
  $field = $filters["field$i"];
  $value = $filters["value$i"];
  if ($field && $value && array_key_exists($field, $fields)) {
    $whereClauses[] = "`$field` LIKE ?";
    $params[] = "%$value%";
    $types .= "s";
  }
}

// فلترة التاريخ
if ($filters['from'] && $filters['to']) {
  $whereClauses[] = "entry_date BETWEEN ? AND ?";
  $params[] = $filters['from'];
  $params[] = $filters['to'];
  $types .= "ss";
} elseif ($filters['from']) {
  $whereClauses[] = "entry_date >= ?";
  $params[] = $filters['from'];
  $types .= "s";
} elseif ($filters['to']) {
  $whereClauses[] = "entry_date <= ?";
  $params[] = $filters['to'];
  $types .= "s";
}

$whereSql = "1";
if (count($whereClauses) > 0) {
  $whereSql = implode(" AND ", $whereClauses);
}

// لحساب إجمالي النتائج (Pagination)
$countSql = "SELECT COUNT(*) as total FROM containers WHERE $whereSql";
$countStmt = $conn->prepare($countSql);
if ($countStmt) {
  if (count($params) > 0) {
    $countStmt->bind_param($types, ...$params);
  }
  $countStmt->execute();
  $countRes = $countStmt->get_result()->fetch_assoc();
  $total_items = $countRes['total'];
  $countStmt->close();
} else {
  die("خطأ في الاستعلام (عدد النتائج): " . $conn->error);
}

// استعلام البيانات مع الترتيب والتجزئة
$sql = "SELECT containers.*, registers.name AS registry_name          FROM containers          LEFT JOIN registers ON containers.registry = registers.id         WHERE $whereSql          ORDER BY `$order_by` $order_dir          LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);

if ($stmt) {
  if (count($params) > 0) {
  $params[] = $items_per_page;
  $params[] = $offset;
  $full_types = $types . "ii";
  $stmt->bind_param($full_types, ...$params);
} else {
  $stmt->bind_param("ii", $items_per_page, $offset);
}

  $stmt->execute();
  $result = $stmt->get_result();
} else {
  die("خطأ في الاستعلام: " . $conn->error);
}

// دالة لترتيب الأعمدة مع تبديل ASC/DESC عند النقر
function sort_link($label, $field, $current_order_by, $current_order_dir, $extra_query) {
  $dir = "ASC";
  $arrow = "";
  if ($current_order_by === $field) {
    if ($current_order_dir === "ASC") {
      $dir = "DESC";
      $arrow = "▲";
    } else {
      $dir = "ASC";
      $arrow = "▼";
    }
  }
  $qs = http_build_query(array_merge($_GET, ['order_by' => $field, 'order_dir' => $dir, 'page' => 1]));
  return "<a href=\"?{$qs}\" style=\"color:inherit; text-decoration:none;\">{$label} {$arrow}</a>";
}

// دالة لعرض القيم مع تحسينات (✅❌ و"غير متوفر")
function displayValue($field, $value) {
  if ($field === 'release_status' || $field === 'company_release') {
    if ($value === '1' || strtolower($value) === 'yes' || strtolower($value) === 'نعم') return "✅";
    if ($value === '0' || strtolower($value) === 'no' || strtolower($value) === 'لا') return "❌";
    return htmlspecialchars($value);
  }
  if ($value === '' || $value === null) {
    return "غير متوفر";
  }
  return htmlspecialchars($value);
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>📦 قائمة الحاويات</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet" />
  <style>
    body { font-family: 'Cairo', sans-serif; background: #f7f7f7; padding: 20px; }
    .header { background: #711739; color: white; padding: 10px 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; }
    .header h4 { margin: 0; font-weight: bold; }
    table th { background: #711739; color: white; font-size: 14px; cursor: pointer; user-select: none; }
    select, input[type=date] { font-size: 14px; }
    @media (max-width: 768px) {
      table, thead, tbody, th, td, tr { font-size: 12px; }
    }
  </style>
</head>
<body>

<div class="header">
  <h4>📦 قائمة الحاويات</h4>
  <div class="d-flex gap-2 flex-wrap">
    <a href="add_container.php" class="btn btn-success btn-sm">➕ إضافة حاوية</a>
    <a href="dashboard.php" class="btn btn-light btn-sm">🏠 القائمة الرئيسية</a>
    <a href="export_excel.php" class="btn btn-outline-success btn-sm">📤 تصدير Excel</a>
  </div>
</div>

<form class="row g-2 mb-3" method="GET" id="filterForm">
  <?php for ($i = 1; $i <= 3; $i++): ?>
    <?php
      $used = array_filter([$filters['field1'], $filters['field2'], $filters['field3']]);
      $fieldKey = "field$i";
      $valueKey = "value$i";
    ?>
    <div class="col-md-2">
      <select name="<?= $fieldKey ?>" class="form-select filter-field" data-index="<?= $i ?>">
        <option value="">فلتر <?= $i ?></option>
        <?php foreach ($fields as $key => $label): ?>
          <?php if (!in_array($key, array_diff($used, [$filters[$fieldKey]]))): ?>
            <option value="<?= $key ?>" <?= ($filters[$fieldKey] == $key ? 'selected' : '') ?>><?= $label ?></option>
          <?php endif; ?>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2">
      <?php if ($filters[$fieldKey]): ?>
        <select name="<?= $valueKey ?>" class="form-select" onchange="this.form.submit()">
          <option value="">-- اختر --</option>
          <?php foreach (getOptions($filters[$fieldKey], $conn) as $opt): ?>
            <option value="<?= htmlspecialchars($opt) ?>" <?= ($filters[$valueKey] == $opt ? 'selected' : '') ?>><?= htmlspecialchars($opt) ?></option>
          <?php endforeach; ?>
        </select>
      <?php else: ?>
        <input type="text" name="<?= $valueKey ?>" class="form-control" value="<?= htmlspecialchars($filters[$valueKey]) ?>" placeholder="اكتب للبحث" />
      <?php endif; ?>
    </div>
  <?php endfor; ?>

  <div class="col-md-2">
    <input type="date" name="from" value="<?= htmlspecialchars($filters['from']) ?>" class="form-control" />
  </div>
  <div class="col-md-2">
    <input type="date" name="to" value="<?= htmlspecialchars($filters['to']) ?>" class="form-control" />
  </div>

  <div class="col-md-2 d-flex gap-1">
    <button type="submit" class="btn btn-primary w-100">فلتر</button>
    <a href="containers.php" class="btn btn-outline-secondary w-100">🧹 إزالة الفلاتر</a>
  </div>
</form>

<div class="mb-3">
  <strong>عدد النتائج: <?= $total_items ?></strong>
</div>

<div class="table-responsive">
  <table class="table table-bordered text-center align-middle">
    <thead>
      <tr>
        <th>#</th>
        <th><?= sort_link('تاريخ الشحن', 'entry_date', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('اسم العميل', 'client_name', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('رقم العميل', 'code', $order_by, $order_dir, $_GET) ?></th>
        <th>لودنق</th>
        <th><?= sort_link('رقم الحاوية', 'container_number', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('رقم البوليصة', 'bill_number', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('الصنف', 'category', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('الشركة الناقلة', 'carrier', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('السجل', 'registry', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('تاريخ الوصول المتوقع', 'expected_arrival', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('الباخرة', 'ship_name', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('المحطة الجمركية', 'custom_station', $order_by, $order_dir, $_GET) ?></th>
        <th>ملاحظات</th>
        <th><?= sort_link('تم الإفراج', 'release_status', $order_by, $order_dir, $_GET) ?></th>
        <th><?= sort_link('تم الإفراج من الشركة', 'company_release', $order_by, $order_dir, $_GET) ?></th>
        <th>الإجراء</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($result->num_rows === 0): ?>
        <tr><td colspan="17">لا توجد نتائج مطابقة</td></tr>
      <?php else: ?>
        <?php $i = $offset + 1; while($r = $result->fetch_assoc()): ?>
          <tr>
            <td><?= $i++ ?></td>
            <td><?= displayValue('entry_date', $r['entry_date']) ?></td>
            <td><?= displayValue('client_name', $r['client_name']) ?></td>
            <td><?= displayValue('code', $r['code']) ?></td>
            <td><?= displayValue('loading_number', $r['loading_number']) ?></td>
            <td><?= displayValue('container_number', $r['container_number']) ?></td>
            <td><?= displayValue('bill_number', $r['bill_number']) ?></td>
            <td><?= displayValue('category', $r['category']) ?></td>
            <td><?= displayValue('carrier', $r['carrier']) ?></td>
            <td><?= displayValue('registry', $r['registry_name']) ?></td>
            <td><?= displayValue('expected_arrival', $r['expected_arrival']) ?></td>
            <td><?= displayValue('ship_name', $r['ship_name']) ?></td>
            <td><?= displayValue('custom_station', $r['custom_station']) ?></td>
            <td><?= displayValue('notes', $r['notes']) ?></td>
            <td><?= displayValue('release_status', $r['release_status']) ?></td>
            <td><?= displayValue('company_release', $r['company_release']) ?></td>
            <td>
              <a href="view_container.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-secondary" title="عرض">👁️</a>
              <a href="edit_container.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-warning" title="تعديل">✏️</a>
              <a href="delete_container.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-danger" title="حذف" onclick="return confirm('تأكيد الحذف؟')">🗑️</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Pagination -->
<nav aria-label="Page navigation">
  <ul class="pagination justify-content-center">
    <?php
    $total_pages = ceil($total_items / $items_per_page);
    $base_query = $_GET;
    for ($p = 1; $p <= $total_pages; $p++) {
      $base_query['page'] = $p;
      $page_url = '?' . http_build_query($base_query);
      $active = ($p === $page) ? 'active' : '';
      echo "<li class='page-item $active'><a class='page-link' href='$page_url'>$p</a></li>";
    }
    ?>
  </ul>
</nav>

<script>
  // عند تغيير حقل الفلتر، يتم إعادة تحميل الخيارات لقيمة الفلتر
  document.querySelectorAll('.filter-field').forEach(select => {
    select.addEventListener('change', function() {
      // إعادة ضبط قيمة القيمة (valueX) عند تغيير الحقل (fieldX)
      const index = this.getAttribute('data-index');
      const valueSelect = document.querySelector(`select[name="value${index}"], input[name="value${index}"]`);
      if (valueSelect) {
        if (this.value === '') {
          valueSelect.value = '';
          valueSelect.style.display = 'inline-block';
        } else {
          // نعيد إرسال النموذج ليتم تحديث الخيارات على السيرفر (دون AJAX)
          document.getElementById('filterForm').submit();
        }
      }
    });
  });
</script>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
