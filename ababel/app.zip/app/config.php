<?php
// تأكد أن لا يوجد فراغ قبل هذا السطر
error_reporting(E_ALL);
ini_set('display_errors', 1);

// إعدادات الاتصال
$host = '91.204.209.18';
$db   = 'mwzubfuj_ababel_db';
$user = 'mwzubfuj_khan';
$pass = 'Khan@70990100';

// الاتصال بقاعدة البيانات
$conn = new mysqli($host, $user, $pass, $db);

// التحقق من نجاح الاتصال
if ($conn->connect_error) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        "error" => "❌ فشل الاتصال بقاعدة البيانات",
        "details" => $conn->connect_error
    ]);
    exit;
}
?>
