<?php
ini_set('display_errors',1);
error_reporting(E_ALL);
include 'config.php';
session_start();

$user_id = $_SESSION['user_id'];

if (!isset($_POST['client_id'], $_POST['type'], $_POST['description'], $_POST['amount'], $_POST['exchange_rate'], $_POST['payment_method'], $_POST['container_id'])) {
    die("⚠️ بيانات ناقصة.");
}

$client_id = intval($_POST['client_id']);
$type = $_POST['type'];
$description = $_POST['description'];
$amount = floatval($_POST['amount']);
$exchange_rate = floatval($_POST['exchange_rate']);
$payment_method = $_POST['payment_method'];
$container_id = intval($_POST['container_id']);
$reference_number = $_POST['reference_number'] ?? '';
$register_id = isset($_POST['register_id']) ? intval($_POST['register_id']) : null;
$actual_cost = isset($_POST['actual_cost']) ? floatval($_POST['actual_cost']) : null;
$receipt_image = '';

if ($amount <= 0) {
    die("⚠️ لا يمكن أن يكون المبلغ صفر أو أقل.");
}

if ($description === 'سجل' && !$register_id) {
    die("⚠️ يجب اختيار سجل عند اختيار البيان 'سجل'.");
}

$stmt = $conn->prepare("INSERT INTO transactions (
    client_id, type, description, amount, exchange_rate, payment_method,
    container_id, reference_number, actual_cost, register_id, serial, created_at
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NOW())");

$stmt->bind_param(
    "issdssissi",
    $client_id, $type, $description, $amount, $exchange_rate,
    $payment_method, $container_id, $reference_number, $actual_cost, $register_id
);

if ($stmt->execute()) {
    $transaction_id = $stmt->insert_id;
    $serial = date('Ymd') . '-' . $transaction_id;
    $conn->query("UPDATE transactions SET serial = '$serial' WHERE id = $transaction_id");

    if ($description === 'تأمين' && $type === 'قبض') {
        $conn->query("UPDATE clients SET insurance_balance = insurance_balance + $amount WHERE id = $client_id");

        $stmt2 = $conn->prepare("INSERT INTO cashbox (type, source, description, method, amount, client_id, user_id, created_at)
            VALUES ('قبض', 'رصيد التأمين', ?, ?, ?, ?, ?, NOW())");
        $stmt2->bind_param("ssdii", $description, $payment_method, $amount, $client_id, $user_id);
        $stmt2->execute();
    } elseif ($payment_method === 'من التأمين') {
        $check = $conn->query("SELECT insurance_balance FROM clients WHERE id = $client_id")->fetch_assoc();
        if ($check['insurance_balance'] < $amount) {
            die("⚠️ رصيد التأمين غير كافٍ.");
        }
        $conn->query("UPDATE clients SET insurance_balance = insurance_balance - $amount, balance = balance + $amount WHERE id = $client_id");

        $stmt3 = $conn->prepare("INSERT INTO cashbox (type, source, description, method, amount, client_id, user_id, created_at)
            VALUES ('قبض', 'تحويل من التأمين', ?, ?, ?, ?, ?, NOW())");
        $stmt3->bind_param("ssdii", $description, $payment_method, $amount, $client_id, $user_id);
        $stmt3->execute();
    } elseif ($description === 'تأمين' && $type === 'استرداد') {
        $conn->query("UPDATE clients SET insurance_balance = insurance_balance - $amount WHERE id = $client_id");

        $stmt4 = $conn->prepare("INSERT INTO cashbox (type, source, description, method, amount, client_id, user_id, created_at)
            VALUES ('صرف', 'استرداد التأمين', ?, ?, ?, ?, ?, NOW())");
        $stmt4->bind_param("ssdii", $description, $payment_method, $amount, $client_id, $user_id);
        $stmt4->execute();
    } elseif ($description !== 'تأمين') {
        if ($type === 'قبض') {
            $conn->query("UPDATE clients SET balance = balance + $amount WHERE id = $client_id");

            $cash = $conn->prepare("INSERT INTO cashbox (transaction_id, client_id, amount, type, source, description, method, user_id, created_at)
                VALUES (?, ?, ?, 'قبض', 'دخل خارجي', ?, ?, ?, NOW())");
            $cash->bind_param("iisssi", $transaction_id, $client_id, $amount, $description, $payment_method, $user_id);
            $cash->execute();
        } elseif ($type === 'مطالبة') {
            $conn->query("UPDATE clients SET balance = balance - $amount WHERE id = $client_id");
        }
    }
    file_put_contents('last_change.txt', time());
    header("Location: profile.php?id=$client_id");
    exit;
} else {
    die("❌ فشل في حفظ المعاملة: " . $conn->error);
}
?>
