
<?php
$host = '91.204.209.18';
$db   = 'mwzubfuj_ababel_db';
$user = 'mwzubfuj_khan';
$pass = 'Khan@70990100';

$backup_file = 'ababel_backup_' . date('Ymd_His') . '.sql';
$command = "mysqldump -h {$host} -u {$user} -p\"{$pass}\" {$db} > {$backup_file}";

system($command);

// تسجيل وقت آخر نسخة احتياطية
file_put_contents('last_backup.txt', time());

if (file_exists($backup_file)) {
  header('Content-Description: File Transfer');
  header('Content-Type: application/octet-stream');
  header("Content-Disposition: attachment; filename=\"$backup_file\"");
  header('Content-Length: ' . filesize($backup_file));
  flush();
  readfile($backup_file);
  unlink($backup_file);
  exit;
} else {
  echo "❌ فشل في إنشاء النسخة الاحتياطية.";
}
?>
