<?php
session_start();
include 'config.php';
$registers = $conn->query("SELECT id, name FROM registers");

$client_id = $_GET['id'] ?? 0;
$client = $conn->query("SELECT * FROM clients WHERE id = $client_id")->fetch_assoc();

if (!$client) {
  die("<div style='text-align:center; margin-top:50px; font-size:18px; color:#c00;'>⚠️ لا يوجد عميل بهذا المعرف: <strong>$client_id</strong></div>");
}

$transactions = $conn->query("
  SELECT t.*, c.container_number, t.created_at 
  FROM transactions t 
  LEFT JOIN containers c ON t.container_id = c.id 
  WHERE t.client_id = $client_id 
  ORDER BY t.id DESC
");

$containers = $conn->query("SELECT * FROM containers WHERE code = '{$client['code']}' ORDER BY entry_date DESC");

$role = $_SESSION['role'] ?? '';
$can_delete = in_array($role, ['مدير عام', 'مدير']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>بروفايل العميل</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    .badge-مطالبة { background-color: #ffc107; color: #000; }
    .badge-قبض { background-color: #28a745; }
    .badge-استرداد { background-color: #dc3545; }
    #actual-cost-group {
  transition: all 0.4s ease-in-out;
}
  </style>
</head>
<body>
<div class="container mt-4">

  <!-- معلومات العميل -->
  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-primary text-white">👤 بيانات العميل</div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-6"><strong>الاسم:</strong> <?= $client['name'] ?></div>
        <div class="col-md-6"><strong>رقم الهاتف:</strong> <?= $client['phone'] ?></div>
        <div class="col-md-6"><strong>الرمز:</strong> <?= $client['code'] ?></div>
        <div class="col-md-6"><strong>تاريخ الإضافة:</strong> <?= $client['start_date'] ?></div>
      </div>
      <hr>
      <?php
$rate_result = $conn->query("SELECT exchange_rate FROM settings ORDER BY id DESC LIMIT 1");
$exchange_rate = $rate_result && $rate_result->num_rows > 0 ? (float) $rate_result->fetch_assoc()['exchange_rate'] : 1;
?>

      <div class="row">
        <div class="col-md-6">
          <label class="form-label text-success">الرصيد الحالي:</label>
          <input class="form-control bg-light" value="<?= number_format($client['balance'] ?? 0, 2); ?> جنيه" readonly>
        </div>
        <div class="col-md-6">
          <label class="form-label text-primary">رصيد التأمين:</label>
          <input class="form-control bg-light" value="<?= number_format($client['insurance_balance'] ?? 0, 2); ?> جنيه" readonly>
        </div>
      </div>
      <div class="row mt-3">
  <div class="col-md-6">
    <label class="form-label text-muted">💵 الرصيد الحالي بالدولار:</label>
    <input class="form-control bg-light" value="<?= number_format(($client['balance'] ?? 0) / ($exchange_rate ?: 1), 2); ?> $" readonly>
  </div>
  <div class="col-md-6">
    <label class="form-label text-muted">💵 رصيد التأمين بالدولار:</label>
    <input class="form-control bg-light" value="<?= number_format(($client['insurance_balance'] ?? 0) / ($exchange_rate ?: 1), 2); ?> $" readonly>
  </div>
</div>

    </div>
  </div>

  <!-- كشف الحساب -->
   <?php
$rate_result = $conn->query("SELECT exchange_rate FROM settings ORDER BY id DESC LIMIT 1");
$exchange_rate = $rate_result && $rate_result->num_rows > 0 ? (float) $rate_result->fetch_assoc()['exchange_rate'] : 1;
?>

  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-dark text-white">📑 كشف حساب العميل</div>
    <div class="card-body table-responsive">
      <table class="table table-bordered text-center align-middle">
        <thead class="table-light">
          <tr>
            <th>التاريخ</th>
            <th>البيان</th>
            <th>المبلغ</th>
            <th>المبلغ بالدولار</th>
            <th>النوع</th>
            <th>الحاوية</th>
            <th>خيارات</th>
          </tr>
        </thead>
        <tbody>
  <?php if ($transactions->num_rows > 0): while($row = $transactions->fetch_assoc()): ?>
    <tr>
      <td><?= $row['created_at'] ?></td>
      <td><?= $row['description'] ?></td>
      <td><?= number_format($row['amount'] ?? 0, 2) ?> جنيه</td>
      <td><?= number_format(($row['amount'] ?? 0) / ($exchange_rate ?: 1), 2) ?> $</td>
      <td><span class="badge badge-<?= $row['type'] ?>"><?= $row['type'] ?></span></td>
      <td><?= $row['container_number'] ?: '-' ?></td>
      <td>
        <a href="receipt_view.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-secondary">👁️</a>
        <a href="edit_receipt.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">✏️</a>
        <a href="print_receipt.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-info">🖨️</a>
        <?php if ($can_delete): ?>
          <a href="delete_receipt.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من الحذف؟')">🗑️</a>
        <?php endif; ?>
      </td>
    </tr>
  <?php endwhile; else: ?>
    <tr><td colspan="7">لا توجد معاملات مسجلة</td></tr>
  <?php endif; ?>
</tbody>

      </table>
    </div>
  </div>
</div>
</body>
</html>
  <!-- إضافة معاملة -->
  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-success text-white">➕ إضافة معاملة جديدة</div>
    <div class="card-body">
      <form action="insert_transaction.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="client_id" value="<?= $client['id'] ?>">
        <input type="hidden" name="client_code" value="<?= $client['code'] ?>">

        <div class="row mb-3">
          <div class="col-md-4">
            <label>نوع المعاملة:</label>
            <select name="type" class="form-control" required>
              <option value="">اختر</option>
              <option value="مطالبة">مطالبة</option>
              <option value="قبض">قبض</option>
              <option value="استرداد">استرداد</option>
            </select>
          </div>
          <div class="col-md-4">
            <label>البيان:</label>
            <select name="description" class="form-select" required id="description-select">
              <option value="">اختر البيان</option>
              <option value="سجل">سجل</option>
              <option value="موانئ">موانئ</option>
              <option value="أرضيات">أرضيات</option>
              <option value="تختيم">تختيم</option>
              <option value="تأمين">تأمين</option>
            </select>
          </div>
          <div class="col-md-4" id="registry_col" style="display:none;">
            <label>السجل:</label>
            <select name="register_id" class="form-select">
              <option value="">اختر سجل</option>
              <?php $registers->data_seek(0); while($reg = $registers->fetch_assoc()): ?>
              <option value="<?= $reg['id'] ?>"><?= htmlspecialchars($reg['name']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-4">
            <label>المبلغ:</label>
            <input type="number" name="amount" class="form-control" required min="1">
          </div>
          
          <div class="col-md-4" id="payment-method-group">
            <label>طريقة الدفع:</label>
            <select name="payment_method" class="form-control">
              <option value="">اختر</option>
              <option>كاش</option>
              <option>بنكك</option>
              <option>أوكاش</option>
              <option>فوري</option>
              <option>شيك</option>
              <option>من التأمين</option>
            </select>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label>رقم الحاوية:</label>
            <select name="container_id" class="form-control" required>
              <option value="">اختر الحاوية</option>
              <?php $res = $conn->query("SELECT * FROM containers WHERE code = '{$client['code']}'");
              while($c = $res->fetch_assoc()): ?>
              <option value="<?= $c['id'] ?>"><?= $c['container_number'] ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label>سعر الصرف:</label>
            <?php $rate_result = $conn->query("SELECT exchange_rate FROM settings ORDER BY id DESC LIMIT 1");
           $exchange_rate = $rate_result ? $rate_result->fetch_assoc()['exchange_rate'] : 0; ?>
            <input type="number" name="exchange_rate" class="form-control" value="<?= $exchange_rate ?>" readonly>
          </div>
        </div>

        

        <button type="submit" class="btn btn-success">💾 إضافة المعاملة</button>
      </form>
    </div>
  </div>

  <!-- الحاويات -->
  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-info text-white">📦 الحاويات المرتبطة بالعميل</div>
    <div class="card-body table-responsive">
      <table class="table table-bordered text-center align-middle">
        <thead class="table-light">
          <tr>
            <th>تاريخ الشحن</th>
            <th>رقم الحاوية</th>
            <th>الكراتين</th>
            <th>اللودنق</th>
            <th>الناقلة</th>
            <th>الصنف</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($containers->num_rows > 0): while($c = $containers->fetch_assoc()): ?>
          <tr>
            <td><?= $c['entry_date'] ?></td>
            <td><?= $c['container_number'] ?></td>
            <td><?= $c['carton_count'] ?></td>
            <td><?= $c['loading_number'] ?></td>
            <td><?= $c['carrier'] ?></td>
            <td><?= $c['category'] ?></td>
          </tr>
          <?php endwhile; else: ?>
          <tr><td colspan="6">لا توجد حاويات مسجلة</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const desc = document.getElementById('description-select');
  const registryCol = document.getElementById('registry_col');
  const actualCostGroup = document.getElementById('actual-cost-group');
  const typeSelect = document.querySelector('select[name="type"]');
  const paymentGroup = document.getElementById('payment-method-group');

  function toggleRegistry() {
    if (desc && desc.value === 'سجل') {
      registryCol.style.display = 'block';
    } else {
      registryCol.style.display = 'none';
    }
  }

  function toggleActualCost() {
    if (desc && desc.value === 'موانئ') {
      actualCostGroup?.classList.add('d-none');
    } else {
      actualCostGroup?.classList.remove('d-none');
    }
  }

  function togglePaymentMethod() {
    if (typeSelect.value === 'مطالبة') {
      paymentGroup.style.display = 'none';
    } else {
      paymentGroup.style.display = 'block';
    }
  }

  function updateDescription() {
    if (typeSelect.value === 'استرداد') {
      desc.innerHTML = '<option value="تأمين" selected>تأمين</option>';
      desc.setAttribute('readonly', true);
    } else {
      desc.removeAttribute('readonly');
      desc.innerHTML = `
        <option value="">اختر البيان</option>
        <option value="سجل">سجل</option>
        <option value="موانئ">موانئ</option>
        <option value="أرضيات">أرضيات</option>
        <option value="تختيم">تختيم</option>
        <option value="تأمين">تأمين</option>
      `;
    }
    toggleRegistry();
    toggleActualCost();
    togglePaymentMethod();
  }

  desc?.addEventListener('change', function () {
    toggleRegistry();
    toggleActualCost();
  });

  typeSelect?.addEventListener('change', updateDescription);

  // تشغيل كل شيء عند التحميل
  toggleRegistry();
  toggleActualCost();
  togglePaymentMethod();
});
</script>
