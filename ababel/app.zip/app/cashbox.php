<?php
include 'config.php';
include 'auth.php';

// الرصيد العام = المقبوض - المصروف (بدون التأمين)
$sum_in = $conn->query("SELECT SUM(amount) as total FROM cashbox WHERE type = 'قبض' AND (source IS NULL OR source != 'رصيد التأمين')")->fetch_assoc()['total'] ?? 0;
$sum_out = $conn->query("SELECT SUM(amount) as total FROM cashbox WHERE type = 'صرف' AND (source IS NULL OR source != 'استرداد التأمين')")->fetch_assoc()['total'] ?? 0;
$balance = $sum_in - $sum_out;

// رصيد التأمين
$insurance_in = $conn->query("SELECT SUM(amount) as total FROM cashbox WHERE type = 'قبض' AND source = 'رصيد التأمين'")->fetch_assoc()['total'] ?? 0;
$insurance_refund = $conn->query("SELECT SUM(amount) as total FROM cashbox WHERE type = 'صرف' AND source = 'استرداد التأمين'")->fetch_assoc()['total'] ?? 0;
$insurance_transfer = $conn->query("SELECT SUM(amount) as total FROM cashbox WHERE type = 'قبض' AND source = 'تحويل من التأمين'")->fetch_assoc()['total'] ?? 0;
$insurance_balance = $insurance_in - $insurance_refund - $insurance_transfer;

// فلترة
$type = $_GET['type'] ?? '';
$source = $_GET['source'] ?? '';
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';
$where = "1";

if (isset($_GET['type']) && in_array($type, ['قبض', 'صرف'])) {
  $where .= " AND cb.type = '$type'";
}

if (!empty($source)) {
  $where .= " AND cb.source = '" . mysqli_real_escape_string($conn, $source) . "'";
}

if ($from && $to) {
  $where .= " AND DATE(cb.created_at) BETWEEN '$from' AND '$to'";
}


// العمليات
$res = $conn->query("
  SELECT cb.*, u.full_name AS user_name
  FROM cashbox cb
  LEFT JOIN users u ON cb.user_id = u.id
  WHERE $where
  ORDER BY cb.id DESC
  LIMIT 100
");
if (!$res) {
  echo "<div style='color:red;text-align:center;'>خطأ في الاستعلام: " . $conn->error . "</div>";
  exit;
}

?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>الخزنة</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body { font-family: 'Cairo', sans-serif; padding: 20px; background: #f8f9fa; }
    .stat-box { border-radius: 10px; padding: 20px; color: white; }
    .bg-balance { background-color: #711739; }
    .bg-insurance { background-color: #198754; }
    .filter-form input, .filter-form select { font-size: 14px; }
    .table td, .table th { vertical-align: middle; }
    .row-in { background-color: #e8f5e9; }
    .row-out { background-color: #fff3cd; }
  </style>
</head>
<body>

<div class="container">
  <h3 class="mb-4">📦 صفحة الخزنة</h3>

  <div class="row g-3 mb-4">
    <div class="col-md-6">
      <div class="stat-box bg-balance">
        <h5>💰 الرصيد الحالي</h5>
        <h3><?= number_format($balance) ?> جنيه</h3>
      </div>
    </div>
    <div class="col-md-6">
      <div class="stat-box bg-insurance">
        <h5>🛡️ رصيد التأمين</h5>
        <h3><?= number_format($insurance_balance) ?> جنيه</h3>
      </div>
    </div>
  </div>

  <form class="row g-2 mb-4 filter-form" method="GET">
    <div class="col-md-2">
      <select name="type" class="form-select">
  <option value="">كل الأنواع</option>
  <option value="قبض" <?= $type === 'قبض' ? 'selected' : '' ?>>قبض</option>
  <option value="صرف" <?= $type === 'صرف' ? 'selected' : '' ?>>صرف</option>
</select>

    </div>
    <div class="col-md-3">
  <select name="source" class="form-select">
    <option value="">كل المصادر</option>
    <option <?= $source === 'رصيد التأمين' ? 'selected' : '' ?>>رصيد التأمين</option>
    <option <?= $source === 'استرداد التأمين' ? 'selected' : '' ?>>استرداد التأمين</option>
    <option <?= $source === 'تحويل من التأمين' ? 'selected' : '' ?>>تحويل من التأمين</option>
    <option <?= $source === 'صرف يومي' ? 'selected' : '' ?>>صرف يومي</option>
    <option <?= $source === 'مصروفات مكتب' ? 'selected' : '' ?>>مصروفات مكتب</option>
    <option <?= $source === 'إجراءات حكومية' ? 'selected' : '' ?>>إجراءات حكومية</option>
    <option <?= $source === 'صرف سجل' ? 'selected' : '' ?>>صرف سجل</option>
    <option <?= $source === 'صرف موانئ' ? 'selected' : '' ?>>صرف موانئ</option>
    <option <?= $source === 'صرف تختيم' ? 'selected' : '' ?>>صرف تختيم</option>
  </select>
</div>

    <div class="col-md-2">
      <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from) ?>">
    </div>
    <div class="col-md-2">
      <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to) ?>">
    </div>
    <div class="col-md-3">
      <button class="btn btn-dark w-100">🔍 بحث</button>
    </div>
  </form>

  <div class="mb-3">
<!-- داخل div الأزرار -->
<a href="office_expense.php" class="btn btn-outline-dark">➕ إضافة مصروف مكتب</a>
<a href="daily_income.php" class="btn btn-outline-dark">➕ إضافة يومية قبض</a>
<a href="daily_expense.php" class="btn btn-outline-dark">➕ إضافة يومية صرف</a>
<a href="dashboard.php" class="btn btn-outline-secondary">🏠 رجوع للرئيسية</a>
  <h5 class="mb-3">📋 آخر العمليات</h5>
  <div class="table-responsive">
    <table class="table table-bordered align-middle text-center">
      <thead class="table-dark">
        <tr>
          <th>التاريخ</th>
          <th>رقم العملية</th>
          <th>النوع</th>
          <th>المصدر</th>
          <th>البيان</th>
          <th>الطريقة</th>
          <th>المبلغ</th>
          <th>الموظف</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($res && $res->num_rows > 0): ?>
  <?php while($row = $res->fetch_assoc()): ?>
    <tr class="<?= $row['type'] === 'قبض' ? 'row-in' : 'row-out' ?>">
      <td><?= date("Y-m-d", strtotime($row['created_at'])) ?></td>
      <td><?= date("Ymd", strtotime($row['created_at'])) . '-' . $row['id'] ?></td>
      <td><?= $row['type'] ?></td>
      <td><?= $row['source'] ?? '-' ?></td>
      <td><?= $row['description'] ?></td>
      <td><?= $row['method'] ?? '-' ?></td>
      <td><?= number_format($row['amount']) ?></td>
      <td><?= $row['user_name'] ?? 'غير معروف' ?></td>
    </tr>
  <?php endwhile; ?>
<?php else: ?>
  <tr><td colspan="8" class="text-center text-danger">لا توجد عمليات لعرضها.</td></tr>
<?php endif; ?>
           
      </tbody>
    </table>
  </div>
</div>

</body>
</html>