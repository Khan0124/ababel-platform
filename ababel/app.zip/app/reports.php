<?php
include 'auth.php';
include 'config.php';

// البيانات التجريبية
$clients = $conn->query("SELECT * FROM clients LIMIT 10");
$containers = $conn->query("SELECT * FROM containers LIMIT 10");
$registers = $conn->query("SELECT r.name, 
  SUM(CASE WHEN t.type = 'مطالبة' THEN t.amount ELSE 0 END) AS debit,
  SUM(CASE WHEN t.type = 'قبض' THEN t.amount ELSE 0 END) AS credit
  FROM registers r LEFT JOIN transactions t ON r.id = t.register_id GROUP BY r.id LIMIT 10");
$expenses = $conn->query("SELECT * FROM cashbox WHERE type='صرف' AND source='مصروفات مكتب' ORDER BY created_at DESC LIMIT 10");
$transactions = $conn->query("SELECT t.*, c.name as client_name FROM transactions t LEFT JOIN clients c ON t.client_id = c.id ORDER BY t.created_at DESC LIMIT 10");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>📊 تقارير النظام - شركة أبابيل</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body { font-family: 'Cairo', sans-serif; background: #f4f4f4; padding: 20px; }
    .section { background: white; padding: 20px; border-radius: 10px; margin-bottom: 30px; box-shadow: 0 0 10px #ccc; }
    .table th { background: #711739; color: white; }
    .top-header {
      background: #711739; color: white; padding: 10px 20px;
      display: flex; justify-content: space-between; align-items: center;
    }
    .top-header img { height: 50px; margin-left: 10px; }
    .top-header .company-name {
      font-size: 18px;
    }
    .report-toggle { margin-bottom: 25px; }
    .section.hidden { display: none; }
  </style>
  <script>
    function toggleReport(sectionId) {
      const allSections = document.querySelectorAll('.section');
      allSections.forEach(s => s.classList.add('hidden'));
      if (sectionId !== 'all') {
        document.getElementById(sectionId).classList.remove('hidden');
      } else {
        allSections.forEach(s => s.classList.remove('hidden'));
      }
    }
  </script>
</head>
<body>
  <div class="top-header">
    <div class="d-flex align-items-center">
      <img src="logo.png" alt="شعار">
      <div class="company-name">
        شركة أبابيل للتنمية والاستثمار المحدودة<br>
        Ababeel Development & Investment Co. Ltd
      </div>
    </div>
    <a href="dashboard.php" class="btn btn-light">🏠 الرجوع للرئيسية</a>
  </div>

  <div class="container mt-4">
    <div class="report-toggle text-center">
      <label class="form-label fw-bold">عرض تقرير:</label>
      <select class="form-select w-auto d-inline-block" onchange="toggleReport(this.value)">
        <option value="all">📊 كل التقارير</option>
        <option value="report-clients">📋 العملاء</option>
        <option value="report-containers">📦 الحاويات</option>
        <option value="report-registers">📁 السجلات</option>
        <option value="report-expenses">💸 المصروفات</option>
        <option value="report-transactions">📑 المعاملات</option>
      </select>
    </div>

    <div id="report-clients" class="section">
      <h4>📋 تقرير العملاء</h4>
      <table class="table table-bordered text-center">
        <thead><tr><th>#</th><th>الاسم</th><th>الكود</th><th>الرصيد</th><th>رصيد التأمين</th></tr></thead>
        <tbody>
          <?php $i=1; while($c = $clients->fetch_assoc()): ?>
            <tr>
              <td><?= $i++ ?></td>
              <td><?= $c['name'] ?></td>
              <td><?= $c['code'] ?></td>
              <td><?= number_format($c['balance'], 2) ?></td>
              <td><?= number_format($c['insurance_balance'], 2) ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <div id="report-containers" class="section">
      <h4>📦 تقرير الحاويات</h4>
      <table class="table table-bordered text-center">
        <thead><tr><th>#</th><th>رقم العميل</th><th>رقم الحاوية</th><th>الحالة</th><th>تاريخ الدخول</th></tr></thead>
        <tbody>
          <?php $i=1; while($c = $containers->fetch_assoc()): ?>
            <tr>
              <td><?= $i++ ?></td>
              <td><?= $c['code'] ?></td>
              <td><?= $c['container_number'] ?></td>
              <td><?= $c['status'] ?? '-' ?></td>
              <td><?= $c['entry_date'] ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <div id="report-registers" class="section">
      <h4>📁 تقرير السجلات</h4>
      <table class="table table-bordered text-center">
        <thead><tr><th>#</th><th>اسم السجل</th><th>مطالبات</th><th>مقبوضات</th><th>الرصيد</th></tr></thead>
        <tbody>
          <?php $i=1; while($r = $registers->fetch_assoc()): ?>
            <tr>
              <td><?= $i++ ?></td>
              <td><?= $r['name'] ?></td>
              <td><?= number_format($r['debit'], 2) ?></td>
              <td><?= number_format($r['credit'], 2) ?></td>
              <td><?= number_format($r['debit'] - $r['credit'], 2) ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <div id="report-expenses" class="section">
      <h4>💸 تقرير المصروفات الإدارية</h4>
      <table class="table table-bordered text-center">
        <thead><tr><th>التاريخ</th><th>النوع</th><th>المبلغ</th><th>ملاحظات</th></tr></thead>
        <tbody>
          <?php while($e = $expenses->fetch_assoc()): ?>
            <tr>
              <td><?= $e['created_at'] ?></td>
              <td><?= $e['description'] ?></td>
              <td><?= number_format($e['amount'], 2) ?></td>
              <td><?= $e['notes'] ?? '-' ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <div id="report-transactions" class="section">
      <h4>📑 تقرير المعاملات المالية</h4>
      <table class="table table-bordered text-center">
        <thead><tr><th>التاريخ</th><th>النوع</th><th>البيان</th><th>المبلغ</th><th>العميل</th></tr></thead>
        <tbody>
          <?php while($t = $transactions->fetch_assoc()): ?>
            <tr>
              <td><?= $t['created_at'] ?></td>
              <td><?= $t['type'] ?></td>
              <td><?= $t['description'] ?></td>
              <td><?= number_format($t['amount'], 2) ?></td>
              <td><?= $t['client_name'] ?? '-' ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
