
CREATE TABLE IF NOT EXISTS containers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(100),
    client VARCHAR(100),
    status VARCHAR(50)
);
