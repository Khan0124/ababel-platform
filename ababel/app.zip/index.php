<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>شركة أبابيل للتنمية والاستثمار</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Cairo', sans-serif;
      background: linear-gradient(135deg, #711739, #99004d);
      color: white;
      margin: 0;
      padding: 0;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      overflow-x: hidden;
    }

    .logo {
      max-height: 80px;
      margin-bottom: 20px;
      animation: slideDown 1s ease-out;
    }

    h1 {
      font-size: 28px;
      font-weight: bold;
      text-align: center;
      animation: fadeIn 1.5s ease-in-out;
    }

    .btn-group {
      display: flex;
      flex-direction: column;
      gap: 15px;
      margin-top: 40px;
      width: 100%;
      max-width: 300px;
      animation: fadeInUp 2s ease-in-out;
    }

    .btn-custom {
      background: white;
      color: #711739;
      font-weight: bold;
      border: none;
      padding: 15px;
      font-size: 16px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
      transition: 0.3s;
    }

    .btn-custom:hover {
      transform: translateY(-3px);
      background-color: #f8f8f8;
    }

    .footer-note {
      margin-top: 40px;
      font-size: 14px;
      text-align: center;
      opacity: 0.8;
      animation: fadeIn 2.5s ease-in;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes slideDown {
      from { transform: translateY(-50px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }

    @keyframes fadeInUp {
      from { transform: translateY(50px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }

    @media (max-width: 576px) {
      h1 { font-size: 20px; }
      .btn-custom { font-size: 14px; padding: 12px; }
    }
  </style>
</head>
<body>

  <img src="logo.png" alt="Ababel Logo" class="logo">
  <h1>شركة أبابيل للتنمية والاستثمار المحدودة</h1>

  <div class="btn-group">
    <a href="app/client_login.php" class="btn btn-custom">دخول العملاء</a>
    <a href="app/login.php" class="btn btn-custom">دخول الموظفين</a>
    <a href="guest.php" class="btn btn-custom"> الدخول كضيف</a>
  </div>

  <div class="footer-note">
    شركة متخصصة في الاستيراد، التخليص الجمركي، والخدمات اللوجستية الذكية.
  </div>

</body>
</html>